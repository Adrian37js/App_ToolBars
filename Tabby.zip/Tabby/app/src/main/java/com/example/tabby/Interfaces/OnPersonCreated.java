package com.example.tabby.Interfaces;

public interface OnPersonCreated {


}
