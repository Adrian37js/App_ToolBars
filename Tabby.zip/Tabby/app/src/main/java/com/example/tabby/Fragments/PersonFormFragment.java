package com.example.tabby.Fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.tabby.Interfaces.OnPersonCreated;
import com.example.tabby.Models.Country;
import com.example.tabby.R;

import java.util.List;


public class PersonFormFragment extends Fragment {

    private EditText editTextName;
    private Spinner spinnerCountry;
    private Button btnCreate;

    private List<Country> countries;
    private OnPersonCreated onPersonCreated;


    public PersonFormFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.form_activity, container, false);
        //Cogemos los ID de form_activity.xml
        editTextName = (EditText) view.findViewById(R.id.editTextName);
        spinnerCountry = (Spinner) view.findViewById(R.id.spinner_ciudades);
        btnCreate = (Button) view.findViewById(R.id.btnCreatePerson);
        ArrayAdapter<Country> adapter = new ArrayAdapter<Country>(getContext(), android.R.layout.simple_spinner_dropdown_item, countries);

        spinnerCountry.setAdapter(adapter);


        return view;
    }
}